import { useState } from "react";
import { Search, MessageCircle, Heart, UserPlus, Star } from "lucide-react";
import { BottomNavigation } from "@/components/bottom-navigation";
import { formatNumber } from "@/lib/mock-data";

interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  user: {
    username: string;
    avatar: string;
    verified: boolean;
  };
  content?: string;
  videoThumbnail?: string;
  timestamp: string;
  read: boolean;
}

export default function Inbox() {
  const [activeTab, setActiveTab] = useState<'all' | 'likes' | 'comments' | 'mentions' | 'followers'>('all');
  
  const notifications: Notification[] = [
    {
      id: "1",
      type: "like",
      user: {
        username: "sofia_beats",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c1b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        verified: false
      },
      videoThumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      timestamp: "2h",
      read: false
    },
    {
      id: "2",
      type: "comment",
      user: {
        username: "dj_marco",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        verified: true
      },
      content: "Adorei essa batida! 🔥",
      videoThumbnail: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      timestamp: "5h",
      read: false
    },
    {
      id: "3",
      type: "follow",
      user: {
        username: "maria_dance",
        avatar: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        verified: true
      },
      timestamp: "1d",
      read: true
    },
    {
      id: "4",
      type: "mention",
      user: {
        username: "live_music",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        verified: true
      },
      content: "Te mencionei em um vídeo incrível!",
      videoThumbnail: "https://images.unsplash.com/photo-1506157786151-b8491531f063?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      timestamp: "2d",
      read: true
    },
    {
      id: "5",
      type: "like",
      user: {
        username: "music_lover",
        avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        verified: false
      },
      videoThumbnail: "https://images.unsplash.com/photo-1504609813442-a8924e83f76e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      timestamp: "3d",
      read: true
    }
  ];

  const getFilteredNotifications = () => {
    switch (activeTab) {
      case 'likes':
        return notifications.filter(n => n.type === 'like');
      case 'comments':
        return notifications.filter(n => n.type === 'comment');
      case 'mentions':
        return notifications.filter(n => n.type === 'mention');
      case 'followers':
        return notifications.filter(n => n.type === 'follow');
      default:
        return notifications;
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart size={16} className="text-vinil-red fill-vinil-red" />;
      case 'comment':
        return <MessageCircle size={16} className="text-vinil-blue" />;
      case 'follow':
        return <UserPlus size={16} className="text-vinil-green" />;
      case 'mention':
        return <Star size={16} className="text-vinil-pink" />;
      default:
        return null;
    }
  };

  const getNotificationText = (notification: Notification) => {
    switch (notification.type) {
      case 'like':
        return "curtiu seu vídeo";
      case 'comment':
        return "comentou";
      case 'follow':
        return "começou a te seguir";
      case 'mention':
        return "te mencionou";
      default:
        return "";
    }
  };

  const tabs = [
    { id: 'all', label: 'Todas' },
    { id: 'likes', label: 'Curtidas' },
    { id: 'comments', label: 'Comentários' },
    { id: 'mentions', label: 'Menções' },
    { id: 'followers', label: 'Seguidores' }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 bg-black bg-opacity-90 backdrop-blur-lg border-b border-gray-800 p-4 pt-12">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold">Inbox</h1>
          <button data-testid="button-search-notifications">
            <Search size={20} className="text-white" />
          </button>
        </div>
        
        {/* Tabs */}
        <div className="flex space-x-1 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'bg-vinil-red text-white' 
                  : 'bg-gray-800 text-gray-400'
              }`}
              data-testid={`button-tab-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 py-6 pb-24">
        {/* Notifications List */}
        <div className="space-y-3">
          {getFilteredNotifications().map(notification => (
            <div 
              key={notification.id}
              className={`flex items-center space-x-3 p-3 rounded-lg ${
                notification.read ? 'bg-gray-900 bg-opacity-50' : 'bg-gray-800'
              }`}
              data-testid={`notification-${notification.id}`}
            >
              {/* User Avatar */}
              <div className="relative">
                <img
                  src={notification.user.avatar}
                  alt="User avatar"
                  className="w-12 h-12 rounded-full"
                />
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-gray-900 rounded-full flex items-center justify-center">
                  {getNotificationIcon(notification.type)}
                </div>
              </div>

              {/* Content */}
              <div className="flex-1">
                <div className="flex items-center space-x-1">
                  <span className="font-semibold">@{notification.user.username}</span>
                  {notification.user.verified && (
                    <div className="w-4 h-4 bg-vinil-blue rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                  <span className="text-gray-400">{getNotificationText(notification)}</span>
                </div>
                
                {notification.content && (
                  <p className="text-gray-300 text-sm mt-1">
                    {notification.content}
                  </p>
                )}
                
                <span className="text-gray-500 text-xs">
                  {notification.timestamp}
                </span>
              </div>

              {/* Video Thumbnail */}
              {notification.videoThumbnail && (
                <img
                  src={notification.videoThumbnail}
                  alt="Video thumbnail"
                  className="w-12 h-16 rounded-lg object-cover"
                />
              )}

              {/* Unread Indicator */}
              {!notification.read && (
                <div className="w-2 h-2 bg-vinil-red rounded-full"></div>
              )}
            </div>
          ))}
        </div>

        {getFilteredNotifications().length === 0 && (
          <div className="text-center py-16">
            <MessageCircle size={48} className="text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-400 mb-2">
              Nenhuma notificação
            </h3>
            <p className="text-gray-500">
              Você não tem notificações deste tipo ainda.
            </p>
          </div>
        )}
      </div>

      <BottomNavigation activeTab="inbox" onTabChange={() => {}} />
    </div>
  );
}