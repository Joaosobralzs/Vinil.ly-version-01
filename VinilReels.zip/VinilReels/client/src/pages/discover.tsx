import { Search, TrendingUp, Music, Hash } from "lucide-react";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function Discover() {
  const trendingHashtags = [
    { tag: "vinil", count: 1200000 },
    { tag: "dance", count: 980000 },
    { tag: "music", count: 850000 },
    { tag: "beats", count: 720000 },
    { tag: "dj", count: 650000 },
  ];

  const popularSounds = [
    { title: "Som Original", artist: "sofia_beats", uses: 45000 },
    { title: "Underground Beat", artist: "dj_marco", uses: 28000 },
    { title: "Live Performance", artist: "RockBand", uses: 89000 },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 bg-black bg-opacity-90 backdrop-blur-lg border-b border-gray-800 p-4 pt-12">
        <div className="flex items-center space-x-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar vídeos, usuários, sons..."
              className="w-full bg-gray-800 rounded-full py-3 pl-10 pr-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-vinil-red"
              data-testid="input-search"
            />
          </div>
        </div>
      </div>

      <div className="px-4 py-6 pb-24">
        {/* Trending Section */}
        <section className="mb-8">
          <div className="flex items-center mb-4">
            <TrendingUp className="text-vinil-red mr-2" size={20} />
            <h2 className="text-xl font-bold">Em Alta</h2>
          </div>
          
          <div className="space-y-3">
            {trendingHashtags.map((item, index) => (
              <div 
                key={item.tag}
                className="flex items-center justify-between p-3 rounded-lg bg-gray-900"
                data-testid={`trending-item-${index}`}
              >
                <div className="flex items-center">
                  <Hash className="text-vinil-blue mr-2" size={16} />
                  <span className="font-medium">#{item.tag}</span>
                </div>
                <span className="text-gray-400 text-sm">
                  {(item.count / 1000000).toFixed(1)}M vídeos
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Popular Sounds */}
        <section>
          <div className="flex items-center mb-4">
            <Music className="text-vinil-green mr-2" size={20} />
            <h2 className="text-xl font-bold">Sons Populares</h2>
          </div>
          
          <div className="space-y-3">
            {popularSounds.map((sound, index) => (
              <div 
                key={index}
                className="flex items-center justify-between p-3 rounded-lg bg-gray-900"
                data-testid={`sound-item-${index}`}
              >
                <div>
                  <div className="font-medium">{sound.title}</div>
                  <div className="text-gray-400 text-sm">{sound.artist}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">
                    {(sound.uses / 1000).toFixed(1)}K
                  </div>
                  <div className="text-gray-400 text-xs">usos</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <BottomNavigation activeTab="discover" onTabChange={() => {}} />
    </div>
  );
}
