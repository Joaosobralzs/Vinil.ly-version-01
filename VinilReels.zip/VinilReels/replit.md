# Overview

This is a TikTok-like social video application called "vinil.ly" built with a modern full-stack architecture. The app provides a vertical video feed where users can watch, like, comment, share, and follow creators. It features a mobile-first design with smooth scrolling between videos and typical social media interactions.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript for type safety and modern component development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state and custom hooks for local state
- **UI Components**: Radix UI primitives with shadcn/ui component library for accessible, customizable components
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js for the REST API server
- **Language**: TypeScript for end-to-end type safety
- **Data Storage**: In-memory storage with interface for future database integration
- **API Design**: RESTful endpoints for videos, users, likes, and follows
- **Development**: Hot reload with Vite middleware integration

## Data Layer
- **ORM**: Drizzle ORM configured for PostgreSQL with schema definitions
- **Database**: PostgreSQL (configured but using in-memory storage currently)
- **Schema**: Well-defined tables for users, videos, follows, and likes with proper relationships
- **Validation**: Zod schemas for runtime type checking and API validation

## Development Environment
- **Monorepo Structure**: Shared types and schemas between client and server
- **Hot Reload**: Vite dev server with Express middleware for seamless development
- **Path Aliases**: TypeScript path mapping for clean imports
- **Code Quality**: Consistent TypeScript configuration across all packages

## Key Design Patterns
- **Component Composition**: Modular UI components following atomic design principles
- **Hook-based Logic**: Custom hooks for video management, user interactions, and state
- **Type-first Development**: Shared TypeScript interfaces between frontend and backend
- **Responsive Design**: Mobile-first approach with desktop adaptations

# External Dependencies

## Core Frameworks
- **React**: Frontend framework with hooks and context
- **Express.js**: Backend web framework for API endpoints
- **Drizzle ORM**: Type-safe database toolkit for PostgreSQL

## UI and Styling
- **Radix UI**: Headless component primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library built on Radix

## Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Static type checking
- **Wouter**: Lightweight routing library
- **React Query**: Server state management and caching

## Database and Hosting
- **Neon Database**: Serverless PostgreSQL database (configured via @neondatabase/serverless)
- **Replit**: Development and hosting environment with specialized plugins

## Utilities
- **date-fns**: Date manipulation and formatting
- **clsx/tailwind-merge**: Conditional CSS class handling
- **zod**: Runtime type validation and schema definition
- **nanoid**: Unique ID generation