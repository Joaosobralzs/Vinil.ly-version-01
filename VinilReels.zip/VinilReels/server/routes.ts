import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVideoSchema, insertFollowSchema, insertLikeSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get video feed
  app.get("/api/videos", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const offset = parseInt(req.query.offset as string) || 0;
      
      const videos = await storage.getVideos(limit, offset);
      res.json(videos);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch videos" });
    }
  });

  // Get specific video
  app.get("/api/videos/:id", async (req, res) => {
    try {
      const video = await storage.getVideo(req.params.id);
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }
      res.json(video);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch video" });
    }
  });

  // Create new video
  app.post("/api/videos", async (req, res) => {
    try {
      const videoData = insertVideoSchema.parse(req.body);
      const video = await storage.createVideo(videoData);
      res.status(201).json(video);
    } catch (error) {
      res.status(400).json({ error: "Invalid video data" });
    }
  });

  // Like a video
  app.post("/api/videos/:id/like", async (req, res) => {
    try {
      const videoId = req.params.id;
      const { userId } = req.body;

      if (!userId) {
        return res.status(400).json({ error: "User ID required" });
      }

      const isLiked = await storage.isVideoLiked(userId, videoId);
      
      if (isLiked) {
        await storage.unlikeVideo(userId, videoId);
        const video = await storage.getVideo(videoId);
        if (video) {
          await storage.updateVideoStats(videoId, video.likes - 1);
        }
        res.json({ liked: false });
      } else {
        await storage.likeVideo({ userId, videoId });
        const video = await storage.getVideo(videoId);
        if (video) {
          await storage.updateVideoStats(videoId, video.likes + 1);
        }
        res.json({ liked: true });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to toggle like" });
    }
  });

  // Share a video (increment share count)
  app.post("/api/videos/:id/share", async (req, res) => {
    try {
      const videoId = req.params.id;
      const video = await storage.getVideo(videoId);
      
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }

      await storage.updateVideoStats(videoId, undefined, undefined, video.shares + 1);
      res.json({ shared: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to share video" });
    }
  });

  // Follow a user
  app.post("/api/users/:id/follow", async (req, res) => {
    try {
      const followingId = req.params.id;
      const { followerId } = req.body;

      if (!followerId) {
        return res.status(400).json({ error: "Follower ID required" });
      }

      const isFollowing = await storage.isFollowing(followerId, followingId);
      
      if (isFollowing) {
        await storage.unfollowUser(followerId, followingId);
        res.json({ following: false });
      } else {
        await storage.followUser({ followerId, followingId });
        res.json({ following: true });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to toggle follow" });
    }
  });

  // Get user profile
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
