import { useState, useCallback } from 'react';
import { VideoWithUser } from '@shared/schema';
import { mockVideos } from '@/lib/mock-data';

export function useVideos() {
  const [videos, setVideos] = useState<VideoWithUser[]>(mockVideos);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);

  const toggleLike = useCallback((videoId: string) => {
    setVideos(prev => 
      prev.map(video => 
        video.id === videoId 
          ? { 
              ...video, 
              isLiked: !video.isLiked,
              likes: video.isLiked ? video.likes - 1 : video.likes + 1
            }
          : video
      )
    );
  }, []);

  const toggleFollow = useCallback((userId: string) => {
    setVideos(prev => 
      prev.map(video => 
        video.userId === userId 
          ? { ...video, isFollowing: !video.isFollowing }
          : video
      )
    );
  }, []);

  const incrementShares = useCallback((videoId: string) => {
    setVideos(prev => 
      prev.map(video => 
        video.id === videoId 
          ? { ...video, shares: video.shares + 1 }
          : video
      )
    );
  }, []);

  return {
    videos,
    currentVideoIndex,
    setCurrentVideoIndex,
    toggleLike,
    toggleFollow,
    incrementShares,
  };
}
