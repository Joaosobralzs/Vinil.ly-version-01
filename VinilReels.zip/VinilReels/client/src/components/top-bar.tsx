import { Search, Menu } from "lucide-react";

interface TopBarProps {
  onSearchClick?: () => void;
}

export function TopBar({ onSearchClick }: TopBarProps) {
  return (
    <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-4 pt-12 glass-effect">
      <button 
        className="text-white text-xl"
        onClick={onSearchClick}
        data-testid="button-search"
      >
        <Search size={24} />
      </button>
      
      <div className="text-white font-bold text-xl tracking-wider">
        vinil.ly
      </div>
      
      <button 
        className="text-white text-xl"
        data-testid="button-menu"
      >
        <Menu size={24} />
      </button>
    </div>
  );
}
