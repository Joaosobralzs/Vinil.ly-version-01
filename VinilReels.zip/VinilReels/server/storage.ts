import { type User, type InsertUser, type Video, type InsertVideo, type VideoWithUser, type Follow, type InsertFollow, type Like, type InsertLike } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Videos
  getVideos(limit?: number, offset?: number): Promise<VideoWithUser[]>;
  getVideo(id: string): Promise<VideoWithUser | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoStats(id: string, likes?: number, comments?: number, shares?: number, views?: number): Promise<Video | undefined>;
  
  // Follows
  followUser(follow: InsertFollow): Promise<Follow>;
  unfollowUser(followerId: string, followingId: string): Promise<boolean>;
  isFollowing(followerId: string, followingId: string): Promise<boolean>;
  
  // Likes
  likeVideo(like: InsertLike): Promise<Like>;
  unlikeVideo(userId: string, videoId: string): Promise<boolean>;
  isVideoLiked(userId: string, videoId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private videos: Map<string, Video>;
  private follows: Map<string, Follow>;
  private likes: Map<string, Like>;

  constructor() {
    this.users = new Map();
    this.videos = new Map();
    this.follows = new Map();
    this.likes = new Map();
    
    // Initialize with mock data
    this.initializeMockData();
  }

  private initializeMockData() {
    // Create mock users
    const mockUsers = [
      {
        id: "user1",
        username: "sofia_beats",
        displayName: "Sofia Beats",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c1b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        followers: 125000,
        following: 342,
        verified: false,
        createdAt: new Date("2023-06-01"),
      },
      {
        id: "user2",
        username: "dj_marco",
        displayName: "DJ Marco",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        followers: 87500,
        following: 198,
        verified: true,
        createdAt: new Date("2023-03-15"),
      },
      {
        id: "user3",
        username: "maria_dance",
        displayName: "Maria Dance",
        avatar: "https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        followers: 234000,
        following: 567,
        verified: true,
        createdAt: new Date("2022-11-20"),
      },
      {
        id: "user4",
        username: "live_music",
        displayName: "Live Music",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
        followers: 456000,
        following: 123,
        verified: true,
        createdAt: new Date("2022-08-10"),
      },
    ];

    mockUsers.forEach(user => this.users.set(user.id, user));

    // Create mock videos
    const mockVideos = [
      {
        id: "1",
        userId: "user1",
        title: "Descobri essa batida incrível!",
        description: "Descobri essa batida incrível! 🎵✨",
        hashtags: ["vinil", "music", "beats", "discover"],
        videoUrl: "https://example.com/video1.mp4",
        thumbnailUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1080&h=1920",
        musicTitle: "Som Original",
        musicArtist: "sofia_beats",
        likes: 12500,
        comments: 2100,
        shares: 845,
        views: 45000,
        createdAt: new Date("2024-01-15"),
      },
      {
        id: "2",
        userId: "user2",
        title: "Mix exclusivo da madrugada",
        description: "Mix exclusivo da madrugada 🔥🎧",
        hashtags: ["dj", "mix", "techno", "nightlife", "vinil"],
        videoUrl: "https://example.com/video2.mp4",
        thumbnailUrl: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?ixlib=rb-4.0.3&auto=format&fit=crop&w=1080&h=1920",
        musicTitle: "Underground Beat",
        musicArtist: "dj_marco",
        likes: 8700,
        comments: 532,
        shares: 234,
        views: 28000,
        createdAt: new Date("2024-01-14"),
      },
      {
        id: "3",
        userId: "user3",
        title: "Novo passo que aprendi hoje!",
        description: "Novo passo que aprendi hoje! 💃✨",
        hashtags: ["dança", "tutorial", "vibes", "dance"],
        videoUrl: "https://example.com/video3.mp4",
        thumbnailUrl: "https://images.unsplash.com/photo-1504609813442-a8924e83f76e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1080&h=1920",
        musicTitle: "Som Original",
        musicArtist: "maria_dance",
        likes: 15200,
        comments: 1800,
        shares: 967,
        views: 52000,
        createdAt: new Date("2024-01-13"),
      },
      {
        id: "4",
        userId: "user4",
        title: "Show épico ontem!",
        description: "Show épico ontem! A energia foi incrível 🔥🎸",
        hashtags: ["show", "concert", "live", "rock", "vinil"],
        videoUrl: "https://example.com/video4.mp4",
        thumbnailUrl: "https://images.unsplash.com/photo-1506157786151-b8491531f063?ixlib=rb-4.0.3&auto=format&fit=crop&w=1080&h=1920",
        musicTitle: "Live Performance",
        musicArtist: "RockBand",
        likes: 23100,
        comments: 3400,
        shares: 1200,
        views: 89000,
        createdAt: new Date("2024-01-12"),
      },
    ];

    mockVideos.forEach(video => this.videos.set(video.id, video));
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      followers: insertUser.followers ?? 0,
      following: insertUser.following ?? 0,
      verified: insertUser.verified ?? false
    };
    this.users.set(id, user);
    return user;
  }

  async getVideos(limit = 20, offset = 0): Promise<VideoWithUser[]> {
    const allVideos = Array.from(this.videos.values())
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(offset, offset + limit);

    const videosWithUsers: VideoWithUser[] = [];
    
    for (const video of allVideos) {
      const user = await this.getUser(video.userId);
      if (user) {
        videosWithUsers.push({
          ...video,
          user,
          isLiked: false, // TODO: Check if current user liked this video
          isFollowing: false, // TODO: Check if current user follows this user
        });
      }
    }

    return videosWithUsers;
  }

  async getVideo(id: string): Promise<VideoWithUser | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;

    const user = await this.getUser(video.userId);
    if (!user) return undefined;

    return {
      ...video,
      user,
      isLiked: false, // TODO: Check if current user liked this video
      isFollowing: false, // TODO: Check if current user follows this user
    };
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = randomUUID();
    const video: Video = { 
      ...insertVideo, 
      id, 
      createdAt: new Date(),
      hashtags: insertVideo.hashtags ?? [],
      likes: insertVideo.likes ?? 0,
      comments: insertVideo.comments ?? 0,
      shares: insertVideo.shares ?? 0,
      views: insertVideo.views ?? 0
    };
    this.videos.set(id, video);
    return video;
  }

  async updateVideoStats(id: string, likes?: number, comments?: number, shares?: number, views?: number): Promise<Video | undefined> {
    const video = this.videos.get(id);
    if (!video) return undefined;

    const updatedVideo = {
      ...video,
      likes: likes ?? video.likes,
      comments: comments ?? video.comments,
      shares: shares ?? video.shares,
      views: views ?? video.views,
    };

    this.videos.set(id, updatedVideo);
    return updatedVideo;
  }

  async followUser(follow: InsertFollow): Promise<Follow> {
    const id = randomUUID();
    const followRecord: Follow = { ...follow, id, createdAt: new Date() };
    this.follows.set(id, followRecord);
    return followRecord;
  }

  async unfollowUser(followerId: string, followingId: string): Promise<boolean> {
    const followToRemove = Array.from(this.follows.values()).find(
      f => f.followerId === followerId && f.followingId === followingId
    );
    
    if (followToRemove) {
      this.follows.delete(followToRemove.id);
      return true;
    }
    
    return false;
  }

  async isFollowing(followerId: string, followingId: string): Promise<boolean> {
    return Array.from(this.follows.values()).some(
      f => f.followerId === followerId && f.followingId === followingId
    );
  }

  async likeVideo(like: InsertLike): Promise<Like> {
    const id = randomUUID();
    const likeRecord: Like = { ...like, id, createdAt: new Date() };
    this.likes.set(id, likeRecord);
    return likeRecord;
  }

  async unlikeVideo(userId: string, videoId: string): Promise<boolean> {
    const likeToRemove = Array.from(this.likes.values()).find(
      l => l.userId === userId && l.videoId === videoId
    );
    
    if (likeToRemove) {
      this.likes.delete(likeToRemove.id);
      return true;
    }
    
    return false;
  }

  async isVideoLiked(userId: string, videoId: string): Promise<boolean> {
    return Array.from(this.likes.values()).some(
      l => l.userId === userId && l.videoId === videoId
    );
  }
}

export const storage = new MemStorage();
