import { Music } from "lucide-react";
import { VideoWithUser } from "@shared/schema";

interface VideoInfoProps {
  video: VideoWithUser;
  onFollow: () => void;
}

export function VideoInfo({ video, onFollow }: VideoInfoProps) {
  const isFollowing = video.isFollowing;

  return (
    <div className="absolute bottom-32 left-4 right-20 z-20">
      {/* User Info */}
      <div className="flex items-center mb-3">
        <img 
          src={video.user.avatar} 
          alt="User Avatar" 
          className="w-10 h-10 rounded-full mr-3"
          data-testid="img-user-avatar"
        />
        <span className="text-white font-semibold text-lg" data-testid="text-username">
          @{video.user.username}
        </span>
        <button
          onClick={onFollow}
          className={`ml-3 px-4 py-1 rounded-full text-white text-sm font-medium ${
            isFollowing 
              ? 'border border-white bg-transparent' 
              : 'bg-vinil-red'
          }`}
          data-testid="button-follow"
        >
          {isFollowing ? 'Seguindo' : 'Seguir'}
        </button>
      </div>

      {/* Video Description */}
      <div className="text-white mb-3">
        <p className="text-base leading-relaxed" data-testid="text-description">
          {video.description}
        </p>
        <p className="text-vinil-blue" data-testid="text-hashtags">
          {video.hashtags?.map(tag => `#${tag}`).join(' ') || ''}
        </p>
      </div>

      {/* Music Info */}
      <div className="flex items-center text-white opacity-90">
        <Music size={16} className="mr-2" />
        <span className="text-sm" data-testid="text-music">
          {video.musicTitle} - {video.musicArtist}
        </span>
      </div>
    </div>
  );
}
