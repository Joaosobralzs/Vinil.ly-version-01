import { useEffect, useRef } from "react";
import { VideoWithUser } from "@shared/schema";
import { VideoItem } from "./video-item";

interface VideoFeedProps {
  videos: VideoWithUser[];
  currentVideoIndex: number;
  onVideoChange: (index: number) => void;
  onLike: (videoId: string) => void;
  onComment: (videoId: string) => void;
  onShare: (videoId: string) => void;
  onFollow: (userId: string) => void;
  onSearchClick?: () => void;
}

export function VideoFeed({ 
  videos, 
  currentVideoIndex, 
  onVideoChange, 
  onLike, 
  onComment, 
  onShare, 
  onFollow,
  onSearchClick 
}: VideoFeedProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const isScrollingRef = useRef(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      if (isScrollingRef.current) return;
      
      isScrollingRef.current = true;
      setTimeout(() => {
        const scrollTop = container.scrollTop;
        const videoHeight = window.innerHeight;
        const newIndex = Math.round(scrollTop / videoHeight);
        
        if (newIndex !== currentVideoIndex && newIndex < videos.length) {
          onVideoChange(newIndex);
        }
        isScrollingRef.current = false;
      }, 100);
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, [currentVideoIndex, videos.length, onVideoChange]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch(e.key) {
        case 'ArrowDown':
          e.preventDefault();
          if (currentVideoIndex < videos.length - 1) {
            scrollToVideo(currentVideoIndex + 1);
          }
          break;
        case 'ArrowUp':
          e.preventDefault();
          if (currentVideoIndex > 0) {
            scrollToVideo(currentVideoIndex - 1);
          }
          break;
        case ' ':
          e.preventDefault();
          // TODO: Toggle video play/pause
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [currentVideoIndex, videos.length]);

  const scrollToVideo = (index: number) => {
    const container = containerRef.current;
    if (!container) return;
    
    const targetVideo = container.children[index] as HTMLElement;
    if (targetVideo) {
      targetVideo.scrollIntoView({ behavior: 'smooth' });
      onVideoChange(index);
    }
  };

  return (
    <div 
      ref={containerRef}
      className="video-container h-screen overflow-y-scroll"
      data-testid="container-video-feed"
    >
      {videos.map((video, index) => (
        <VideoItem
          key={video.id}
          video={video}
          index={index}
          onLike={() => onLike(video.id)}
          onComment={() => onComment(video.id)}
          onShare={() => onShare(video.id)}
          onFollow={() => onFollow(video.userId)}
          onSearchClick={onSearchClick}
        />
      ))}
    </div>
  );
}
