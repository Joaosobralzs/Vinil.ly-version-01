import { useState } from "react";
import { Search, TrendingUp, Music, Hash, User, Video, X } from "lucide-react";

interface SearchResult {
  id: string;
  type: 'user' | 'video' | 'hashtag' | 'sound';
  title: string;
  subtitle?: string;
  thumbnail?: string;
  avatar?: string;
  count?: number;
  verified?: boolean;
}

interface SearchPageProps {
  onClose: () => void;
}

export function SearchPage({ onClose }: SearchPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<'all' | 'users' | 'videos' | 'sounds' | 'hashtags'>('all');

  const searchResults: SearchResult[] = [
    {
      id: "1",
      type: "user",
      title: "sofia_beats",
      subtitle: "Sofia Beats • 125K seguidores",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c1b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      verified: false
    },
    {
      id: "2",
      type: "user",
      title: "dj_marco",
      subtitle: "DJ Marco • 87.5K seguidores",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
      verified: true
    },
    {
      id: "3",
      type: "video",
      title: "Descobri essa batida incrível!",
      subtitle: "@sofia_beats • 45K visualizações",
      thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=300"
    },
    {
      id: "4",
      type: "hashtag",
      title: "#vinil",
      subtitle: "1.2M vídeos",
      count: 1200000
    },
    {
      id: "5",
      type: "sound",
      title: "Som Original",
      subtitle: "sofia_beats • 45K usos",
      count: 45000
    },
    {
      id: "6",
      type: "video",
      title: "Mix exclusivo da madrugada",
      subtitle: "@dj_marco • 28K visualizações",
      thumbnail: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=300"
    }
  ];

  const recentSearches = [
    "#dance", "sofia_beats", "techno beats", "#vinil", "maria_dance"
  ];

  const trendingSearches = [
    "#viral", "dj sets", "dance moves", "#music", "live performance"
  ];

  const getFilteredResults = () => {
    if (!searchQuery) return [];
    
    let filtered = searchResults.filter(result => 
      result.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      result.subtitle?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (activeFilter !== 'all') {
      const filterMap = {
        'users': 'user',
        'videos': 'video',
        'sounds': 'sound',
        'hashtags': 'hashtag'
      };
      filtered = filtered.filter(result => result.type === filterMap[activeFilter]);
    }

    return filtered;
  };

  const getResultIcon = (type: string) => {
    switch (type) {
      case 'user':
        return <User size={16} className="text-vinil-blue" />;
      case 'video':
        return <Video size={16} className="text-vinil-red" />;
      case 'sound':
        return <Music size={16} className="text-vinil-green" />;
      case 'hashtag':
        return <Hash size={16} className="text-vinil-pink" />;
      default:
        return null;
    }
  };

  const filters = [
    { id: 'all', label: 'Tudo' },
    { id: 'users', label: 'Usuários' },
    { id: 'videos', label: 'Vídeos' },
    { id: 'sounds', label: 'Sons' },
    { id: 'hashtags', label: 'Hashtags' }
  ];

  return (
    <div className="fixed inset-0 bg-black z-50">
      {/* Header */}
      <div className="sticky top-0 bg-black border-b border-gray-800 p-4 pt-12">
        <div className="flex items-center space-x-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Buscar vídeos, usuários, sons..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-800 rounded-full py-3 pl-10 pr-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-vinil-red"
              data-testid="input-search-main"
              autoFocus
            />
          </div>
          <button 
            onClick={onClose}
            className="text-white"
            data-testid="button-close-search"
          >
            <X size={24} />
          </button>
        </div>

        {/* Filters */}
        {searchQuery && (
          <div className="flex space-x-2 mt-4 overflow-x-auto">
            {filters.map(filter => (
              <button
                key={filter.id}
                onClick={() => setActiveFilter(filter.id as any)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap ${
                  activeFilter === filter.id 
                    ? 'bg-vinil-red text-white' 
                    : 'bg-gray-800 text-gray-400'
                }`}
                data-testid={`button-filter-${filter.id}`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="px-4 py-6">
        {!searchQuery ? (
          <>
            {/* Recent Searches */}
            <section className="mb-8">
              <h2 className="text-lg font-semibold mb-4 text-gray-300">Buscas Recentes</h2>
              <div className="space-y-3">
                {recentSearches.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => setSearchQuery(search)}
                    className="flex items-center justify-between w-full p-3 rounded-lg bg-gray-900 hover:bg-gray-800 transition-colors"
                    data-testid={`button-recent-${index}`}
                  >
                    <div className="flex items-center space-x-3">
                      <Search size={16} className="text-gray-400" />
                      <span className="text-white">{search}</span>
                    </div>
                    <X size={16} className="text-gray-400" />
                  </button>
                ))}
              </div>
            </section>

            {/* Trending */}
            <section>
              <div className="flex items-center mb-4">
                <TrendingUp className="text-vinil-red mr-2" size={20} />
                <h2 className="text-lg font-semibold text-gray-300">Trending</h2>
              </div>
              <div className="space-y-3">
                {trendingSearches.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => setSearchQuery(search)}
                    className="flex items-center space-x-3 w-full p-3 rounded-lg bg-gray-900 hover:bg-gray-800 transition-colors"
                    data-testid={`button-trending-${index}`}
                  >
                    <TrendingUp size={16} className="text-vinil-red" />
                    <span className="text-white">{search}</span>
                  </button>
                ))}
              </div>
            </section>
          </>
        ) : (
          /* Search Results */
          <div className="space-y-3">
            {getFilteredResults().map(result => (
              <div
                key={result.id}
                className="flex items-center space-x-3 p-3 rounded-lg bg-gray-900 hover:bg-gray-800 transition-colors cursor-pointer"
                data-testid={`result-${result.id}`}
              >
                {/* Icon or Avatar/Thumbnail */}
                <div className="w-12 h-12 rounded-lg bg-gray-800 flex items-center justify-center overflow-hidden">
                  {result.avatar ? (
                    <img src={result.avatar} alt="Avatar" className="w-full h-full object-cover rounded-lg" />
                  ) : result.thumbnail ? (
                    <img src={result.thumbnail} alt="Thumbnail" className="w-full h-full object-cover rounded-lg" />
                  ) : (
                    getResultIcon(result.type)
                  )}
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-white">{result.title}</span>
                    {result.verified && (
                      <div className="w-4 h-4 bg-vinil-blue rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">✓</span>
                      </div>
                    )}
                  </div>
                  {result.subtitle && (
                    <p className="text-gray-400 text-sm">{result.subtitle}</p>
                  )}
                </div>

                {/* Type Icon */}
                <div className="flex items-center justify-center w-8 h-8">
                  {getResultIcon(result.type)}
                </div>
              </div>
            ))}

            {getFilteredResults().length === 0 && searchQuery && (
              <div className="text-center py-16">
                <Search size={48} className="text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-400 mb-2">
                  Nenhum resultado encontrado
                </h3>
                <p className="text-gray-500">
                  Tente buscar por algo diferente.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}