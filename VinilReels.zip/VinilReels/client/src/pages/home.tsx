import { useState } from "react";
import { VideoFeed } from "@/components/video-feed";
import { BottomNavigation } from "@/components/bottom-navigation";
import { LoadingOverlay } from "@/components/loading-overlay";
import { SearchPage } from "@/components/search-page";
import { useVideos } from "@/hooks/use-videos";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function Home() {
  const [activeTab, setActiveTab] = useState('home');
  const [isLoading, setIsLoading] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const {
    videos,
    currentVideoIndex,
    setCurrentVideoIndex,
    toggleLike,
    toggleFollow,
    incrementShares,
  } = useVideos();

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    
    switch (tab) {
      case 'discover':
        setLocation('/discover');
        break;
      case 'inbox':
        setLocation('/inbox');
        break;
      case 'profile':
        setLocation('/profile');
        break;
      case 'create':
        setIsLoading(true);
        setTimeout(() => {
          setIsLoading(false);
          toast({
            title: "Em breve!",
            description: "Função de criação em desenvolvimento.",
          });
        }, 2000);
        break;
    }
  };

  const handleComment = (videoId: string) => {
    toast({
      title: "Comentários",
      description: "Função de comentários em desenvolvimento.",
    });
  };

  const handleShare = (videoId: string) => {
    incrementShares(videoId);
    toast({
      title: "Compartilhado!",
      description: "Vídeo compartilhado com sucesso.",
    });
  };

  return (
    <div className="relative h-screen overflow-hidden bg-black">
      {showSearch ? (
        <SearchPage onClose={() => setShowSearch(false)} />
      ) : (
        <>
          <VideoFeed
            videos={videos}
            currentVideoIndex={currentVideoIndex}
            onVideoChange={setCurrentVideoIndex}
            onLike={toggleLike}
            onComment={handleComment}
            onShare={handleShare}
            onFollow={toggleFollow}
            onSearchClick={() => setShowSearch(true)}
          />
          
          <BottomNavigation 
            activeTab={activeTab}
            onTabChange={handleTabChange}
          />
          
          <LoadingOverlay isVisible={isLoading} />
        </>
      )}
    </div>
  );
}
