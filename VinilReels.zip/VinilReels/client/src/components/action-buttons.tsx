import { Heart, MessageCircle, Share, Plus } from "lucide-react";
import { VideoWithUser } from "@shared/schema";
import { formatNumber } from "@/lib/mock-data";

interface ActionButtonsProps {
  video: VideoWithUser;
  onLike: () => void;
  onComment: () => void;
  onShare: () => void;
  onFollow: () => void;
}

export function ActionButtons({ video, onLike, onComment, onShare, onFollow }: ActionButtonsProps) {
  return (
    <div className="absolute right-4 bottom-32 z-20 flex flex-col items-center space-y-6">
      {/* Like Button */}
      <div className="flex flex-col items-center">
        <button
          onClick={onLike}
          className="w-12 h-12 rounded-full bg-gray-800 bg-opacity-70 flex items-center justify-center"
          data-testid="button-like"
        >
          <Heart 
            size={24} 
            className={`${video.isLiked ? 'text-vinil-red fill-vinil-red' : 'text-white'}`}
          />
        </button>
        <span className="text-white text-sm mt-1 font-medium" data-testid="text-likes">
          {formatNumber(video.likes)}
        </span>
      </div>

      {/* Comment Button */}
      <div className="flex flex-col items-center">
        <button
          onClick={onComment}
          className="w-12 h-12 rounded-full bg-gray-800 bg-opacity-70 flex items-center justify-center"
          data-testid="button-comment"
        >
          <MessageCircle size={24} className="text-white" />
        </button>
        <span className="text-white text-sm mt-1 font-medium" data-testid="text-comments">
          {formatNumber(video.comments)}
        </span>
      </div>

      {/* Share Button */}
      <div className="flex flex-col items-center">
        <button
          onClick={onShare}
          className="w-12 h-12 rounded-full bg-gray-800 bg-opacity-70 flex items-center justify-center"
          data-testid="button-share"
        >
          <Share size={24} className="text-white" />
        </button>
        <span className="text-white text-sm mt-1 font-medium" data-testid="text-shares">
          {formatNumber(video.shares)}
        </span>
      </div>

      {/* Profile Circle */}
      <div className="relative">
        <img 
          src={video.user.avatar} 
          alt="User Avatar" 
          className="w-12 h-12 rounded-full border-2 border-white"
          data-testid="img-avatar"
        />
        <button
          onClick={onFollow}
          className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-vinil-red rounded-full flex items-center justify-center"
          data-testid="button-follow-circle"
        >
          <Plus size={14} className="text-white" />
        </button>
      </div>
    </div>
  );
}
