interface LoadingOverlayProps {
  isVisible: boolean;
  message?: string;
}

export function LoadingOverlay({ isVisible, message = "Carregando vídeo..." }: LoadingOverlayProps) {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-vinil-red mx-auto mb-4"></div>
        <p className="text-white" data-testid="text-loading">
          {message}
        </p>
      </div>
    </div>
  );
}
