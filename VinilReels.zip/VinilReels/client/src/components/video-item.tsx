import { VideoWithUser } from "@shared/schema";
import { TopBar } from "./top-bar";
import { ActionButtons } from "./action-buttons";
import { VideoInfo } from "./video-info";

interface VideoItemProps {
  video: VideoWithUser;
  index: number;
  onLike: () => void;
  onComment: () => void;
  onShare: () => void;
  onFollow: () => void;
  onSearchClick?: () => void;
}

const gradientClasses = [
  "gradient-bg-1",
  "gradient-bg-2", 
  "gradient-bg-3",
  "gradient-bg-4"
];

export function VideoItem({ video, index, onLike, onComment, onShare, onFollow, onSearchClick }: VideoItemProps) {
  const gradientClass = gradientClasses[index % gradientClasses.length];

  return (
    <div className={`video-item relative h-screen w-full ${gradientClass} flex items-center justify-center`}>
      {/* Video Background */}
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-80"
        style={{ backgroundImage: `url('${video.thumbnailUrl}')` }}
        data-testid="bg-video"
      />
      
      <TopBar onSearchClick={onSearchClick} />
      
      <ActionButtons 
        video={video}
        onLike={onLike}
        onComment={onComment}
        onShare={onShare}
        onFollow={onFollow}
      />
      
      <VideoInfo 
        video={video}
        onFollow={onFollow}
      />
    </div>
  );
}
