import { useState } from "react";
import { Settings, Share, MoreHorizontal, Grid3X3, Heart, Bookmark, Lock } from "lucide-react";
import { BottomNavigation } from "@/components/bottom-navigation";
import { formatNumber } from "@/lib/mock-data";

export default function Profile() {
  const [activeTab, setActiveTab] = useState<'videos' | 'liked' | 'saved'>('videos');
  const [showSettings, setShowSettings] = useState(false);

  const currentUser = {
    username: "meu_perfil",
    displayName: "Meu Perfil",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b332c1b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100",
    followers: 1250,
    following: 342,
    likes: 45600,
    bio: "Criador de conteúdo musical 🎵 | Amante de vinis 📀",
    verified: false,
  };

  const myVideos = [
    { id: 1, thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 12500, private: false },
    { id: 2, thumbnail: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 8700, private: false },
    { id: 3, thumbnail: "https://images.unsplash.com/photo-1504609813442-a8924e83f76e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 15200, private: true },
    { id: 4, thumbnail: "https://images.unsplash.com/photo-1506157786151-b8491531f063?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 23100, private: false },
    { id: 5, thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 9800, private: false },
    { id: 6, thumbnail: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 7400, private: true },
  ];

  const likedVideos = [
    { id: 1, thumbnail: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 45000 },
    { id: 2, thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 32000 },
    { id: 3, thumbnail: "https://images.unsplash.com/photo-1571330735066-03aaa9429d89?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 28000 },
  ];

  const savedVideos = [
    { id: 1, thumbnail: "https://images.unsplash.com/photo-1504609813442-a8924e83f76e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 52000 },
    { id: 2, thumbnail: "https://images.unsplash.com/photo-1506157786151-b8491531f063?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=400", views: 89000 },
  ];

  const getCurrentVideos = () => {
    switch (activeTab) {
      case 'liked':
        return likedVideos;
      case 'saved':
        return savedVideos;
      default:
        return myVideos;
    }
  };

  const tabs = [
    { id: 'videos', label: 'Vídeos', icon: Grid3X3 },
    { id: 'liked', label: 'Curtidos', icon: Heart },
    { id: 'saved', label: 'Salvos', icon: Bookmark }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="sticky top-0 bg-black bg-opacity-90 backdrop-blur-lg border-b border-gray-800 p-4 pt-12">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold">@{currentUser.username}</h1>
          <div className="flex items-center space-x-4">
            <button data-testid="button-share-profile">
              <Share size={20} className="text-white" />
            </button>
            <button data-testid="button-settings">
              <Settings size={20} className="text-white" />
            </button>
            <button data-testid="button-more">
              <MoreHorizontal size={20} className="text-white" />
            </button>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 pb-24">
        {/* Profile Info */}
        <div className="text-center mb-6">
          <img
            src={currentUser.avatar}
            alt="Profile"
            className="w-24 h-24 rounded-full mx-auto mb-4 border-2 border-vinil-red"
            data-testid="img-profile-avatar"
          />
          
          <h2 className="text-2xl font-bold mb-1" data-testid="text-display-name">
            {currentUser.displayName}
          </h2>
          
          <p className="text-gray-400 mb-4" data-testid="text-bio">
            {currentUser.bio}
          </p>

          {/* Stats */}
          <div className="flex justify-center space-x-8 mb-6">
            <div className="text-center">
              <div className="text-xl font-bold" data-testid="text-following-count">
                {formatNumber(currentUser.following)}
              </div>
              <div className="text-gray-400 text-sm">Seguindo</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold" data-testid="text-followers-count">
                {formatNumber(currentUser.followers)}
              </div>
              <div className="text-gray-400 text-sm">Seguidores</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold" data-testid="text-likes-count">
                {formatNumber(currentUser.likes)}
              </div>
              <div className="text-gray-400 text-sm">Curtidas</div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 mb-6">
            <button 
              className="flex-1 py-2 px-4 bg-vinil-red rounded-lg font-medium"
              data-testid="button-edit-profile"
            >
              Editar perfil
            </button>
            <button 
              className="flex-1 py-2 px-4 border border-gray-600 rounded-lg font-medium"
              data-testid="button-insights"
            >
              Insights
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-gray-800 mb-6">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 flex items-center justify-center py-3 ${
                  activeTab === tab.id 
                    ? 'border-b-2 border-vinil-red text-white' 
                    : 'text-gray-400'
                }`}
                data-testid={`button-tab-${tab.id}`}
              >
                <Icon size={20} className="mr-2" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Videos Grid */}
        <div className="grid grid-cols-3 gap-1">
          {getCurrentVideos().map((video) => (
            <div 
              key={video.id}
              className="relative aspect-[3/4] bg-gray-800 rounded-lg overflow-hidden"
              data-testid={`video-thumbnail-${video.id}`}
            >
              <img
                src={video.thumbnail}
                alt="Video thumbnail"
                className="w-full h-full object-cover"
              />
              
              {/* Private indicator for my videos */}
              {activeTab === 'videos' && 'private' in video && video.private && (
                <div className="absolute top-2 right-2">
                  <Lock size={16} className="text-white" />
                </div>
              )}
              
              <div className="absolute bottom-2 left-2 text-white text-xs font-medium">
                {formatNumber(video.views)}
              </div>
            </div>
          ))}
        </div>

        {getCurrentVideos().length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              {activeTab === 'videos' && <Grid3X3 size={32} className="text-gray-600" />}
              {activeTab === 'liked' && <Heart size={32} className="text-gray-600" />}
              {activeTab === 'saved' && <Bookmark size={32} className="text-gray-600" />}
            </div>
            <h3 className="text-lg font-semibold text-gray-400 mb-2">
              {activeTab === 'videos' && 'Nenhum vídeo ainda'}
              {activeTab === 'liked' && 'Nenhum vídeo curtido'}
              {activeTab === 'saved' && 'Nenhum vídeo salvo'}
            </h3>
            <p className="text-gray-500">
              {activeTab === 'videos' && 'Comece criando seu primeiro vídeo!'}
              {activeTab === 'liked' && 'Vídeos que você curtir aparecerão aqui.'}
              {activeTab === 'saved' && 'Vídeos salvos para assistir depois.'}
            </p>
          </div>
        )}
      </div>

      <BottomNavigation activeTab="profile" onTabChange={() => {}} />
    </div>
  );
}
