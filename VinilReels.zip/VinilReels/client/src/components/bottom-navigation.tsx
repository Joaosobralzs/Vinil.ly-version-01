import { Home, Search, Plus, Inbox, User } from "lucide-react";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BottomNavigation({ activeTab, onTabChange }: BottomNavigationProps) {
  const tabs = [
    { id: 'home', label: 'Início', icon: Home },
    { id: 'discover', label: 'Descobrir', icon: Search },
    { id: 'create', label: 'Criar', icon: Plus, special: true },
    { id: 'inbox', label: 'Inbox', icon: Inbox },
    { id: 'profile', label: 'Perfil', icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-black bg-opacity-90 backdrop-blur-lg border-t border-gray-800 z-30">
      <div className="flex items-center justify-around py-2">
        {tabs.map(({ id, label, icon: Icon, special }) => (
          <button
            key={id}
            onClick={() => onTabChange(id)}
            className="flex flex-col items-center py-2 px-4"
            data-testid={`button-nav-${id}`}
          >
            {special ? (
              <div className="w-8 h-8 bg-gradient-to-r from-vinil-red to-vinil-pink rounded-lg flex items-center justify-center mb-1">
                <Icon size={18} className="text-white" />
              </div>
            ) : (
              <Icon 
                size={20} 
                className={`mb-1 ${activeTab === id ? 'text-white' : 'text-gray-400'}`} 
              />
            )}
            <span 
              className={`text-xs ${activeTab === id ? 'text-white' : 'text-gray-400'}`}
            >
              {label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
